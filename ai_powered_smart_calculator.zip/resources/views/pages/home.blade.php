@extends('layouts.app')
@section('component')
    @include('components.drawPad')
@endsection
